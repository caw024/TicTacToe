#! /usr/bin/python3

HTML_HEADER='Content-type: text/html\n\n'

def Main():
    print (HTML_HEADER+'<html><body>')
    print ('<b> Success. Python is able to generate HTML text.<p>')
    print ('(Now hit the BACK button)</body></html>')

Main()
