http_stuy is a variant of the Python3 http server with the following modification to server.py:
- python and html programs will be executed from any directory