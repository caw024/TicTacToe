chmod +x *.sh *.py http_stuy/*.py ServerTests/*.py
