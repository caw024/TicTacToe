python3 -m http_stuy.server --cgi --bind 127.0.0.1
